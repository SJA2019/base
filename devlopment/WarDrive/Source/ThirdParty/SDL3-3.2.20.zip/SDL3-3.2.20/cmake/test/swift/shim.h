/* Contributed by Piotr Usewicz (https://github.com/pusewicz) */

#include <SDL3/SDL.h>
