You need something with a pen/stylus for this to work.

This takes pen input and draws lines. Lines are darker when you press harder.
