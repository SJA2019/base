This example code looks for the current joystick state once per frame,
and draws a visual representation of it.
