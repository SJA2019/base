This example creates an SDL window and renderer, and then draws a bunch of
single points, moving across the screen.

