This example code creates an SDL window and renderer, and then clears the
window to a different color every frame, so you'll effectively get a window
that's smoothly fading between colors.
